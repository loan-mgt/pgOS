import kivy
from fonction import *

from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty
from kivy.graphics import Rectangle
from kivy.graphics import Color
from kivy.graphics import Line
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window
from kivymd.app import MDApp
from kivymd.icon_definitions import md_icons
####from kivymd.theming import ThemeManager
from kivymd.uix.picker import MDDatePicker
from kivy.properties import ObjectProperty, StringProperty
from kivymd.uix.menu import MDDropdownMenu

import csv
Window.clearcolor = (1, 1, 1, 1)

KV = '''

MDBottomNavigation:
	##"date_selectionneur" : "date_selectionneur"
		MDBottomNavigationItem:
				name: "screnn1"
				#icon: "duck"
				icon: 'format-list-bulleted'
				FloatLayout:
						Label:
								color: (0, 0, 0, 1)
								font_size: 40
								
								text: "List de Pigeon"
								pos_hint: {'x':0, 'y': 0.2}
						Button:
								text: 'Ajouter un Pigeon'
								size_hint: (0.4, 0.1)

								font_size: 40
								
								pos_hint: {'x': 0.3, 'y': 0.15}
								on_release:
										app.btn_valide()
						MDTextField:
								id: nom
								required: True
								font_size : 40
								size_hint: (0.2,0.18)
								pos_hint:{'x': 0.25, 'y': 0.45}
                				hint_text: "Nom du Pigeon"
                		MDTextField:
                				id: num
                				required: True
                				font_size: 40
                				size_hint: (0.2,0.18)
                				pos_hint:{'x': 0.55, 'y': 0.45}
                				hint_text: "Numéro de Bague"
                		MDCheckbox:
                				required: True
						        group: 'M/F'
						        size_hint: None, None
						        size: dp(48), dp(48)
						        pos_hint: {'center_x': .25, 'center_y': .36}
						        on_active:
						        		app.M_call(self.active)
						Label:
								color: (0, 0, 0, 1)
								text:"Malle"
								font_size: 35
								pos_hint: {'center_x': .35, 'center_y': .36}
						MDCheckbox:
						        group: 'M/F'
						        size_hint: None, None
						        size: dp(48), dp(48)
						        pos_hint: {'center_x': .55, 'center_y': .36}
						        on_active:
						        		app.F_call(self.active)
						        		print(self.active)
						Label:
								color: (0, 0, 0, 1)
								text:"Femmelle"
								font_size: 35
								pos_hint: {'center_x': .70, 'center_y': .36}					

		MDBottomNavigationItem:
				name: "screnn2"
				icon: "home-outline"
				FloatLayout:
						Label:
								color: (0, 0, 0, 1)
								font_size: 40
								text: "Acceuil"
								pos_hint: {'x':0, 'y': 0.2}
				
						Label:
								color: (0, 0, 0, 1)
								font_size: 40
								text: app.label_accueil
								pos_hint: {'x':0, 'y': 0.1}
						Button:
								color: (0, 0, 0, 1)
								size_hint: 0.2, 0.1
								font_size: 40
								text: 'demo'
								pos_hint: {'x':0.5, 'y': 0.1}
								on_release: app.root.current="screnn1"



						

				
		MDBottomNavigationItem:
				name: "scren3"
				id: screen3
				icon: "calendar"
				FloatLayout:
						Label:
								color: (0, 0, 0, 1)
								font_size: 40
								text: "Couvaison"
								pos_hint: {'x':0, 'y': 0.3}
						Button:
								id: date_selectionneur
								text: app.label_date if app.label_date != "" else 'Date de Ponte'
								size_hint: (0.4, 0.1)
								font_size: 40
								
								pos_hint: {'x': 0.3, 'y': 0.45}
								on_release:
										app.show_datepicker()
										app.labeltext()
							
		
					    
					    
						Button:
								id: valide_couv
								text: 'Valider'
								pos_hint: {'center_x': 0.5, "center_y": 0.2}
								font_size: 40
								size_hint: (0.4, 0.1)
								on_release:
										app.write_csv_classe(app.label_date,app.fm_select,app.ff_select)
										

						MDDropDownItem:
						        id: field
						        text: app.fmList_0
						        font_size: 40
						        pos_hint: {'center_x': 0.3, 'center_y': 0.35}
						        dropdown_bg: [1, 1, 1, 1]
						        on_release: app.menu.open()
						MDDropDownItem:
						        id: field2
						        text: app.ffList_0
						        font_size: 40
						        pos_hint: {'center_x': 0.6, 'center_y': 0.35}
						        dropdown_bg: [1, 1, 1, 1]
						        on_release: app.menu2.open()
						
'''





print(updatelist([],[])[0])

ffList = []
fmList = []

	
ffList = updatelist([],[])[0]
fmList = updatelist([],[])[1]


class MainApp(MDApp):
	##date_selectionneur= ObjectProperty(None)
	label_accueil = StringProperty('')
	label_date = StringProperty('')
	ffList_0= StringProperty('')
	fmList_0= StringProperty('')
	print(fmList,ffList)
	for i in ffList:
		print(i)

		ffList_0 = i
		break
	for i in fmList:

		fmList_0 = i
		break
	ff_select = "Aucun Pigeon"
	try:
		ff_select = ffList_0
	except:
		ff_select = "Aucun Pigeon"
	
	
	try:
		fm_select = fmList_0
	except:
		fm_select = "Aucun Pigeon"
	
	M_F = None





	print("hello")
	def __init__(self, **kwargs):
        	super().__init__(**kwargs)
        	self.screen = Builder.load_string(KV)
	 	
        	global fmList
        	global ffList
        	if fmList != {}:
        		menu_items = list_to_drop_down(dic_to_list(fmList))
        	else:
        		menu_items = list_to_drop_down(dic_to_list({"Aucun Pigeon":""}))
        	if ffList != {}:
        		menu_items2 = list_to_drop_down(dic_to_list(ffList))
        	else:
        		menu_items2 = list_to_drop_down(dic_to_list({"Aucun Pigeon":""}))
        	
        	self.menu2 = MDDropdownMenu(
                caller=self.screen.ids.field,
                items=menu_items2,
                position="auto",
                callback=self.set_item2,
                width_mult=4,
            )
        	self.menu = MDDropdownMenu(
                caller=self.screen.ids.field,
                items=menu_items,
                position="auto",
                callback=self.set_item,
                width_mult=4,
            )

	def set_item(self, instance):
			
			self.screen.ids.field.text = instance.text
			self.fm_select = instance.text
	def set_item2(self, instance):
        	self.screen.ids.field2.text = instance.text
        	self.ff_select =instance.text
	def show_datepicker(self):
		picker = MDDatePicker(callback = self.got_date)
		picker.open()

	def got_date(self, the_date):
		print(the_date)
		self.label_date = str(the_date)
	def btn_valide(self):
		global M_F
		try:
			
			global fmList
			global ffList
			print(ffList,fmList)

			list_write(M_F,self.screen.ids.nom.text,self.screen.ids.num.text)
			ffList = updatelist([],[])[0]
			fmList = updatelist([],[])[1]

			print("M_F",M_F,"name", self.screen.ids.nom.text, "email", self.screen.ids.num.text)
			if fmList != {}:
				menu_items = list_to_drop_down(dic_to_list(fmList))
			else:
				menu_items = list_to_drop_down(dic_to_list({"Aucun Pigeon":""}))
			if ffList != {}:
				menu_items2 = list_to_drop_down(dic_to_list(ffList))
			else:
				menu_items2 = list_to_drop_down(dic_to_list({"Aucun Pigeon":""}))
			print("recall")
			self.menu2 = MDDropdownMenu(
	                caller=self.screen.ids.field,
	                items=menu_items2,
	                position="auto",
	                callback=self.set_item2,
	                width_mult=4,
	            )
			self.menu = MDDropdownMenu(
	            	caller=self.screen.ids.field,
	                items=menu_items,
	                position="auto",
	                callback=self.set_item,
	                width_mult=4,
	            )
		except:
			print("error")

	def labeltext(self):
		print("hello")
		#self.label_accueil = str(readtest())
	def write_csv_classe(self,date,M,F):
		print(M)
		print(F)
		#write_csv(date,M,F)
	

	def M_call(self,statue):
		if statue == True:
			global M_F
			M_F = "M"
			print(M_F)
	def F_call(self,statue):
		if statue == True:
			global M_F
			M_F = "F"
			print(M_F)

	
	def add_pg(self):
		pass


	
	

	def build(self):
		return self.screen
        


if __name__ == "__main__":
     MainApp().run()
